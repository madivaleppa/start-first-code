
#include<string.h>
#include<stdio.h>
#include"decode.h"
#include"types.h"




/*
   decode read and validate arguments
   * input:argument vector ,structure decode
   * output:return e_success if all arguments are correct else returns e_failure if arguments are wrong
   *description:checks and validate all arguments passed in cl correct or not
   */
Status read_and_validate_decode_args(char* argv[],DecodeInfo* decInfo)
{
    char* ptr;
    ptr=strstr(argv[2],".bmp");
    if(ptr!=NULL && strcmp(ptr,".bmp")==0)
    {//store the name into src_fname
        decInfo->src_fname=argv[2];
        if(argv[3]== NULL)
        {
            strcpy(decInfo->output_fname,"output");
        }
        else
           strcpy(decInfo->output_fname,argv[3]);
        printf("%s",decInfo->output_fname);
        fflush(stdout);

        return e_success;
    }
    else
        printf("\nError: input file is not .bmp file");
        fflush(stdout);
    return e_failure;
}

/*
   do decoding
   * input:decode structure
   * output:return e_success upon sucessful execution of the function else return e_failure if function fails
   *description:encodes the size which is 32 bits into output stego file
   */
Status do_decoding(DecodeInfo* decInfo)
{
    if(decode_open_files(decInfo)==e_success)
    {
        printf("\nfile open success");
        fflush(stdout);
        //skip the header file from the stego .bmp
        if(skip_header(decInfo)==e_success)
        {
            printf("\nsuccess skip header");
            fflush(stdout);
            //decode the magic string
           if(decode_magic_string(decInfo) == e_success)
           {
                printf("\nmagic strin decode success");
                fflush(stdout);
                //decode the file extension size
                if(decode_file_extn_size(decInfo) ==e_success)
                {
                    printf("\nsuccess decode extn size");
                    //decode the file extension
                    if(decode_file_extn(decInfo)==e_success)
                    {
                        printf("\nsuccess decode file extension");
                        //decode the secret file data
                        if(decode_secret_file_data_size(decInfo)==e_success)
                        {
                            printf("\n success secret file data size");
                            //decoding the secret file data
                            if(decode_secret_file_data(decInfo)==e_success)
                            {
                                printf("\n decoding secret file data success");
                                return e_success;
                            }
                        }

                        
                    }
                    else
                    {
                        printf("\nfailed decode file extension");
                    }
                }


           }
           else
           {
               printf("\n decode magic string failed");
               return e_failure;
           }
        }


    }
    else
    {
        printf("\n file open faiure");
        return e_failure;
    }
    return e_success;
}


/*
   decode open files
   * input: structure
   * output:return e_success upon sucessful execution of the function else return e_failure 
   *description:open the source file and assign it to the file pointer ,check the file pointer is null or not 
            if it is null print error msg to return faiure
   */
Status decode_open_files(DecodeInfo* decInfo)
{
    decInfo->fptr_stego_image=fopen(decInfo->src_fname,"r");
    if(decInfo->fptr_stego_image== NULL)
    {
        printf("\nfile Open failed");
        fflush(stdout);
        return e_failure;
    }
    return e_success;
}

//move the offset of file to 54th position to read the encoded data
Status skip_header(DecodeInfo* decInfo)
{
    fseek(decInfo->fptr_stego_image,54,SEEK_SET);
    return e_success;
}

/*
   encode magic string
   * input:structure data
   * output:return e_success upon sucessful execution of the function else return e_failure if magic string doesn't match
   *description:reads the 16 bytes from the stego image and send it to decode byte to lsb to decode it 
                if the returned string matches with the original magic string return success else return failure 
   */
Status decode_magic_string(DecodeInfo* decInfo)
{
    char magic_string[3];//to store the decoded magic string
    char buffer[8];
    int i;
    for(i=0;i<2;i++)
    {
        fread(buffer,8,1,decInfo->fptr_stego_image);
        //decode the buffer data and store it into array
        magic_string[i]=decode_byte_to_lsb(buffer);

    }
    magic_string[i]='\0';

    if(!strcmp(magic_string,"#*"))
        return e_success;
    else
        return e_failure;
}
 

char decode_byte_to_lsb(char* buffer)
{
    char ch=0;
    for(int i=0;i<8;i++)
    {
        ch=ch|((buffer[i]&1)<<i);
    }
    return ch;
}

Status decode_file_extn_size(DecodeInfo* decInfo)
{
    char buffer[32];
    fread(buffer,32,1,decInfo->fptr_stego_image);
    decInfo->extn_size=decode_size_to_lsb(buffer);
//    printf("\nextn size is %d",decInfo->extn_size);
    return e_success; 
}

/*
   decode size to lsb
   * input:character buffer
   * output:returns the decoded character
   *description:collect the last bit of every byte and perform or openration to get the encoded character to be decode
                then return the character
   */
int decode_size_to_lsb(char *buffer)
{
    int n;
    for(int i=0;i<32;i++)
    {
        n=n|((buffer[i]&1)<<i);
    }
    return n;
}

/*
   decode file extension
   * input:structure decode
   * output:return e_success upon successful execution of function else returns e_failure if function fails
   *description:collect the 8 bytes of data from source file and pass it to byte to lsb then do this for extnsion size times
   */
Status decode_file_extn(DecodeInfo* decInfo)
{
    char buffer[8];
    char file_extn[decInfo->extn_size+1];
    int i;
    for(i=0;i<decInfo->extn_size;i++)
    {
        fread(buffer,8,1,decInfo->fptr_stego_image);
        file_extn[i]=decode_byte_to_lsb(buffer);
    }
    file_extn[i]='\0';
    //concatinate the file name with extension
    strcat(decInfo->output_fname,file_extn);
    //open the files
    decInfo->fptr_output_fname=fopen(decInfo->output_fname,"w");
    //do error handling
    if(decInfo->fptr_output_fname==NULL)
    {
        printf("\n open output file failed");
        return e_failure;
    }
    return e_success;
}

//decode the 32 bytes to get the size i.e 32 bits of integer value
Status decode_secret_file_data_size(DecodeInfo* decInfo)
{
    char buffer[32];
    fread(buffer,32,1,decInfo->fptr_stego_image);
    //pass the buffer to decode the integer
    decInfo->data_size=decode_size_to_lsb(buffer);
    return e_success;
}


/*
   decode secret file data
   * input:structure of decode
   * output:return e_success upon successfull execution of the function
   *description:checks and validate all arguments passed in cl correct or not
   */
Status decode_secret_file_data(DecodeInfo* decInfo)
{
    char buffer[8];
    char secret_data[decInfo->data_size+1];
    int i;
    for(i=0;i<decInfo->data_size;i++)
    {
        fread(buffer,8,1,decInfo->fptr_stego_image);
        secret_data[i]=decode_byte_to_lsb(buffer);
    }
    secret_data[i]='\0';
//    printf("\nsecret data is %s",secret_data);
    fwrite(secret_data,decInfo->data_size,1,decInfo->fptr_output_fname);
    fclose(decInfo->fptr_output_fname);
    return e_success;
}
